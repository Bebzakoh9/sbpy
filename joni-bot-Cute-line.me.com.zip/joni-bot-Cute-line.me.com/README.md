#joni-bot


I humans

#git clone https://github.com/bebzakoh9/joni-bot.git
#joni-bot.py
# joni-botsb.py